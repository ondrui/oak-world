/** @prettier */

const OPTS = {
  BASE_OUT_NAME: 'vue-go-top',
  LIBRARY_NAME: 'GoTop',
  PORT: 3000
};

module.exports = OPTS;
